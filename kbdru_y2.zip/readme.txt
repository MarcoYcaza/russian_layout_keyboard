
            Russian Phonetic keyboard layout for Windows 7,8,10/XP/2003/Vista
            =================================================================


  A-A, E-E, K-K, O-O, ... - Phonetic keyboard layout for Russian:
 
  - http://Phon.WinRus.com - in Russian - *** PO-RUSSKI ***
  
  - http://Phonetic.WinRus.com - same instruction in English 



    Paul Gorodyansky    http://WinRus.com
 
            =========================================================
 

                         Variant 'YaWert2'

                         see Info page for details:
                         
                         Info_e.htm - in English
                         Info_r.htm - in Russian *** PO-RUSSKI ***
                         
      -------------------------------------------------------------------- 

